#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

@Slf4j
@RestController
public class ${NAME}Controller {

    @GetMapping({"/", "index"})
    public ApiResult<?> text() {
        return ApiResult.SUCCESS();
    }
    
    
}