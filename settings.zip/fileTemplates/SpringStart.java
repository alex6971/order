#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

#parse("File Header.java")
@SpringBootApplication
public class ${NAME} {

    public static void main(String[] args) {
        SpringApplication.run(${NAME}.class, args);
    }
}
