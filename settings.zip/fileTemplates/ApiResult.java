package alex.summary.example.sms.model;


import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * <p>Title: ApiResult</p>
 * <p>Description: 封装接口返回值</p>
 * @author wyf
 * @date 2020年3月2日
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ApiResult<T> implements Serializable {

    /** 序列化 */
    private static final long serialVersionUID = 1L;

    /** 返回编码 */
    private String code;

    /** 返回消息 */
    private String message;

    /** 返回数据 */
    private T data;


    public static <T> ApiResult<T> SUCCESS(T data) {
        return new ApiResult<>("200", "success", data);
    }

    public static <T> ApiResult<T> FAILURE(T data) {
        return new ApiResult<>("900", "failure", data);
    }
    
    public static <T> ApiResult<T> MESSAGE(String code, String message) {
        return new ApiResult<>(code, message, null);
    }
}
