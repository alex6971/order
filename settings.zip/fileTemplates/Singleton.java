#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

public class ${NAME} {

    /** 
     * 私有的构造方法，防止new   
     */
    private ${NAME}() { }
 
    public static ${NAME} getInstance() {
        return ${NAME}Holder.INSTANCE;
    }
 
    /**
     * 静态内部类
     */
    private static class ${NAME}Holder {
    
        /** 第一次加载内部类的时候，实例化单例对象 */
        private static final ${NAME} INSTANCE = new ${NAME}();
    }
}